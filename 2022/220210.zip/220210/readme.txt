KOKEE - too many clock breaks






