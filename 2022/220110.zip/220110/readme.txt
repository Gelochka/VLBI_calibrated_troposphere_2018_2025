NYALES20 and MATERA are bad






