large clock offset for RAEGSMAR
  




