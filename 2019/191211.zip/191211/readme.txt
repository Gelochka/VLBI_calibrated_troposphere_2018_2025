Koganei is bad

