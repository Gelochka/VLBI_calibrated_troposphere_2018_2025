WETTZ13S is bad




