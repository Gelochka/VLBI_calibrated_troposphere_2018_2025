 weird session, not prepared for LSM
