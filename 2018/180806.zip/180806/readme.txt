Kath12M has a break to 1 sec - corrected in DTAU1. 
No break is required
 
