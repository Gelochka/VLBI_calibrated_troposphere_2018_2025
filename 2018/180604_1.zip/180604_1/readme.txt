YEBES40M is bad

No meteodata for several stations