201128n1.ngs  rua039  4ST   0.5 s, full session, XS_RR_0.500_128__v4  DIFX + manual PIMA
201128n2.ngs  rua039  4ST   0.5 s, full session, XS_RR_0.500_128__v4  TEC_IONOSPHERE  DIFX + manual PIMA
